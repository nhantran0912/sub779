


Downloads:

	1. Apache-commons-net.jar can be downloaded from: http://www.java2s.com/Code/Jar/a/Downloadapachecommonsnetjar.htm
	2. Using "theHarvester" to find emails, sub-domains, and hosts based on the domain. "theHarvester" can be downloaded 		from: Git clone https://github.com/laramies/theHarvester
	3. "http://www.java2s.com/Code/Jar/o/Downloadorgjsonjar.htm"
	


Dataset: 




